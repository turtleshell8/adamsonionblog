#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

int main(){
    char exits[30] = "";
    char item[1] = "";
    // random number genorator
    srand(time(NULL));
    int rand_num = rand() % 3 + 1; 
    // yes i did just copy and paste the code but atleast i understand it OK
    printf("r = rock \n");
    printf("p = paper \n");
    printf("s = siscors \n");
    printf("welcome to rock paper scicors what is your item (r/p/s) ");
    scanf("%s", item);
    if(strcmp(item, "r") == 0 && rand_num == 1){
        printf("its a tie");
        scanf("%s", exits);
    }
    if(strcmp(item, "r") == 0 && rand_num == 2){
        printf("you failed");
        scanf("%s", exits);
    }
    if(strcmp(item, "r") == 0 && rand_num == 3){
        printf("you won");
        scanf("%s", exits);
    }
    // paper
    if(strcmp(item, "p") == 0 && rand_num == 1){
        printf("you won");
        scanf("%s", exits);
    }
    if(strcmp(item, "p") == 0 && rand_num == 2){
        printf("its a tie");
        scanf("%s", exits);
    }
    if(strcmp(item, "p") == 0 && rand_num == 3){
        printf("you failed");
        scanf("%s", exits);
    }
    // scisors
    if(strcmp(item, "s") == 0 && rand_num == 1){
        printf("you failed");
        scanf("%s", exits);
    }
    if(strcmp(item, "s") == 0 && rand_num == 2){
        printf("you won");
        scanf("%s", exits);
    }
    if(strcmp(item, "r") == 0 && rand_num == 3){
        printf("you failed");
        scanf("%s", exits);
    }
}