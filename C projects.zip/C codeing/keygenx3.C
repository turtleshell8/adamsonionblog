#include <cstdio>
#include <string.h>
#include <stdlib.h>
#include <time.h>
int main()
{

// varibles plus seed
char exit[10] = "\0";
int keygen_password = 0;
srand(time(0));
int num_1 = rand() % 6 + 1;
int num_2 = rand() % 6 + 1;
int num_3 = rand() % 6 + 1;
int num_4 = rand() % 6 + 1;
int correct_password = num_1 * 1000 + num_2 * 100 + num_3 * 10 + num_4;
// main guess
printf("hello there user you have three trys to beat this keygen \n");
printf("if you need a hint type in hint on the first try also you have 3 trys \n");
printf("good luck enter the password: ");
scanf("%d", &keygen_password);
if(keygen_password == correct_password){
    printf("correct hackerman or women or nonbinary pal\n");
    scanf("%s", exit);
}
else{
    printf("incorrect hackerman or women or nonbinary pal try again 2 trys left\n");
    printf("enter the password: ");
    scanf("%d", &keygen_password);
    if(keygen_password == correct_password){
        printf("correct hackerman or women or nonbinary pal\n");
        scanf("%s", exit);
    } else {
        printf("incorrect hackerman or women or nonbinary pal. No more 1 try left.\n");
        printf("enter the password: ");
        scanf("%d", &keygen_password);
        if(keygen_password == correct_password){
            printf("correct hackerman or women or nonbinary pal good job and bye\n");
            scanf("%s", exit);
        } else{
            printf("incorrect hackerman or women or nonbinary pal goodbye\n");
            scanf("%s", exit);
        }
    }
}}