#include <cstdio>
#include <string.h>
int main(){
    int password = 0;
    char exit[10] = "\0"; 
    printf("hello there and welcome to my very first crack me this is designed \n");
    printf("to be as simple as possible also you only have one try now what is the password ");
    scanf("%d", &password);
    if(password == 1504){
        printf("correct");
        scanf("%s", exit);
    }
    else{
        printf("wrong try again");
        scanf("%s", exit);
    }
    return 0;
}