#include <fcntl.h>
#include <io.h>
#include <stdio.h>

int main(){
    char exits[30] = "";
    if (_setmode(_fileno(stdout), _O_U16TEXT) == -1)
        return 1;
   
    wprintf(L"   \n\n\n\n    שלום עולם \n\n\n");
    scanf("%s", exits);
 return 0;
}