#include <cstdio>
int main(){
    /*
      format specifiers: a special token that begins with a % symbol
      and some sort of letter they can be used to specify flags 
      width and persicion they also specify wich data is wich
      when useing a variable
    */
    char exit[1] = "";
    int num = 10;
    float num_2 = 10.2;
    double num_3 = 10.3456678956435;
    char letter = 'A'; // has to be single quotes
    char name[] = "bobert timothy jones"; // has to be double quotes remember
    printf("a number %d\n", num); //integer format specifier
    printf("a float %f \n", num_2); //float format specifier
    printf("a double %lf\n", num_3); //double format specifier
    printf("a letter %c\n", letter); //character format specifier
    printf("a name %s\n", name); //string format specifier
    printf("two variables %d %f\n", num, num_2); //multiple variables
    printf("now we are going to the width section\n");
    printf("enter any letter and press enter to exit the game");
    scanf("%s", exit);
    return 0;
}
