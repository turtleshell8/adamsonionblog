#include <cstdio>
#include <stdbool.h>
int main(){
    char exit[1] = "";
    int number = 5;
    int number_2 = 10;
    float floating_point_number = 3.14;
    double big_ass_number = 1234.566785432323; // a double type variable can hold up to 15 or 16 numbers
    char symbol_character = '!'; // yes you must use single quotes for characters and symbols
    char character = 'A';
    char name[] = "bobert"; // was thinking the string would be much worse but no
    bool you_online = true;
    printf("Hello, World!\n");
    printf("The number is: %d\n", number);
    printf("the second number is: %d\n", number_2);
    printf("heres a floating point number %f\n", floating_point_number);
    printf("here is a big ass number %lf\n", big_ass_number); // yes a big ass number variable has to be known as a big ass number or long float in C 💀💀💀
    printf("here is a symbol %c\n", symbol_character);
    printf("here is a letter %c\n", character);
    printf("%s is jimmys last name \n", name);
    printf("two variables!!! %d %d\n", number_2, number);
    printf("you are online right now is %d if 1 = true\n", you_online);
    printf("enter any letter and press enter to exit the game");
    scanf("%s", exit);
    return 0;
}