#include <cstdio>

void birthday()
{
 printf("i touch kids and happy birthday");
}

int main(){
    birthday(); // bro functions were this fucking simple this entire time
    return 0; 
} 