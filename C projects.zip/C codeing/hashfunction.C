#include <stdio.h>
void hash(int a){
    int result = a * a + 10 * 9;
    int reslut = result * 25 + 65 - 20;
    if(result > 1000){
        int result = result + 90; 
    }
    printf("Hash result: %d\n", result);
}

int main(){
    int hash_num = 0;
    printf("enter a number ");
    scanf("%d", &hash_num);
    hash(hash_num);
    scanf("%d", hash_num);
}