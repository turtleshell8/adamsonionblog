#include <cstdio>

int main(){
    int itemCount = 0;
    int itemCount_2 = 0;
    float Price = 0.0f;
    float Price_2 = 0.0f;
    char exit[1] = "";
    printf("Welcome to the Shopping Cart Program!\n");
    printf("How much of a unique item do you want to add to your cart? ");
    scanf("%d", &itemCount);
    printf("How many orther unique items do you want to add to your cart if none just enter 0: ");
    scanf("%d", &itemCount_2);
    printf("what is the price of the first item ");
    scanf("%f", &Price);
    printf("what is the price of the second item ");
    scanf("%f", &Price_2);
    printf("the price you will pay is: %.2f\n", Price * itemCount + Price_2 * itemCount_2);
    printf("Thank you for using the Shopping Cart Program!\n");
    printf("Press any key and then press enter to exit...");
    scanf("%s", exit);
    return 0;
}