#include <cstdio>

int main(){
    int weght_transfer_type = 0; 
    float kilos = 0;
    float pounds = 0;
    float p_to_k = pounds * 0.45359237;
    char exit[30] = "";
    printf("1 = pounds to kilos \n");
    printf("2 = kilos to pounds \n");
    printf("please enter transfer type ");
    scanf("%d", &weght_transfer_type);
    if(weght_transfer_type == 1){
        printf("enter pounds ");
        scanf("%f", &pounds);
        float p_to_k = pounds * 0.45359237;
        printf("%f\n", p_to_k);
        scanf("%s", &exit);
    }
    if(weght_transfer_type == 2){
        printf("enter kilos ");
        scanf("%f", &kilos);
        float k_to_p = kilos * 2.204623;
        printf("%f", k_to_p);
        scanf("%s", &exit);
    }

    return 0;
}