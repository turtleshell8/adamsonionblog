#include <stdio.h>

int main(){
    /*
    a pointer is like a house adress it isint quite the home itself
    but its the way to the house so instead of haveing the all the 
    data ie solare panles ect just a single pointer
    */
    int point1 = 10;
    
    // %zu is the format specifier for type size_t
    printf("an int uses %zu bytes of memory\n", sizeof(int));
    printf("the adress of point1 is %p \n", (void *)&point1);

    // how to make a pointer
    int point2 = 10; // point2 i 10
    int *p; // a pointer is made
    p = &point2; // p points to point2

    printf("point2 is %d \n", point2);
    printf("point2 is %d \n", *p);
    
    // sting/char pointers
    char hello[30] = "hello world";
    char * ptr_str = hello;
    printf("string pointer is %s \n", ptr_str); 
    scanf("%d", p);
    return 0;
}