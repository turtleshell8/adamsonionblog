#include <stdio.h>

int main(){
	char exit[30] = "";
	printf("hello furry artist i would like to commision human art \n");
	printf("furry artist : AAAAAAAAAAAAAAAAAHHHHHHHHHHHHHHHHHHHH \n");
	scanf("%s", exit);
	return 0;
}