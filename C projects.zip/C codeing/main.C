#include <cstdio>

int main(){
    char exit[1] = "";
    // Prints "Hello, World!" to the console
    // were learning C omg this is so cool
    // i love coding in C
    // or is mr python dev
    // not a C developer :(    
    
    /* this is a multi line comment
       wow this is so cool
       i love coding in C
    */
    printf("Hello, World!\n");
    printf("bobert jones timothy\n");
    printf("the third is a silly name\n");
    printf("i love coding in C\n");
    printf("also this is my first program in C\n");
    printf("from bro code (:\n");
    printf("enter any letter and press enter to exit the game");
    scanf("%s", exit);
    return 0;
}

