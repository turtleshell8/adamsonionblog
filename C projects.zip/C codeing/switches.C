#include <cstdio>

int main(void)
{
    int goat_count = 0;

    printf("Enter the number of goats you have: ");
    scanf("%d", &goat_count);

    switch (goat_count) {
        case 0:
            printf("You have no goats.\n");
            break;

        case 1:
            printf("You have a singular goat.\n");
            break;

        case 2:
            printf("You have a brace of goats.\n");
            break;
        default:
            if (goat_count < 0) {
                printf("You have a negative amount of goats this is annomoly in space time as for matter to be and or energy\n");
                printf("to exist in a negetive state would be to defy the laws of physics as we know them today\n");
            } else {
                printf("You have a bona fide plethora of goats!\n");
            }
            break;
        
    }

    return 0;
}