#include <stdbool.h>
#include <stdio.h>

int main(){
    char exit[1] = "";

    // while statements are statements that triger code while a argument is met
    bool bob_is_dead = true;
    
    while(bob_is_dead == true){
        printf("bob is dead *crys \n"); // this will say print "bob is dead *crys" if bob is dead
        break; // this will end a while statement if this is not here it will loop forever 
    }

    while(bob_is_dead == false){
        printf("bob is alive!"); // this will print "bob is alive!" if bob is alive
        break; // this will end a while statement if this is not here it will loop forever 
    }
    scanf("%s", exit);
    return 0;
}