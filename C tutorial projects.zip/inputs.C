#include <cstdio>
int main(){
    int age = 0; 
    char grade = '\0';
    float gpa = 0.0f;
    char name[30];
    char exit[1] = "";

    printf("Enter your age: ");
    scanf("%d", &age);

    printf("Enter your grade: ");
    scanf(" %c", &grade);

    printf("Enter your GPA: ");
    scanf("%f", &gpa);
    
    getchar(); // To consume the newline character left by previous scanf
    printf("Enter your full name: ");
    fgets(name, sizeof(name), stdin); // Using fgets to read a string with spaces

    printf("your age is %d\n", age);
    printf("your grade is %c\n", grade);
    printf("your gpa is %f\n", gpa);
    printf("your name is %s\n", name);
    printf("enter any letter and press enter to exit the game");
    scanf("%s", exit);

    return 0;
}