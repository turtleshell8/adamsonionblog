#include <cstdio>

void birthday()
{
 printf("i touch kids and happy birthday");
}

int main(){
    char exits[30] = "";
    birthday(); // bro functions were this fucking simple this entire time
    scanf("%s", exits);
    return 0; 
} 