#!/bin/bash
# this greets the user
echo "hello there $USER"
