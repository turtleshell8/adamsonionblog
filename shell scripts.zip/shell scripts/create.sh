#!/bin/bash

echo "enter the name of the file you want to make: "
read name_file
echo "created $name_file"
touch $name_file
