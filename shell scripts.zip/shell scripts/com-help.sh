#!/bin/bash

xdg-open https://www.geeksforgeeks.org/linux-unix/linux-commands-cheat-sheet/
