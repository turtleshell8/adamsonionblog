#!/bin/bash

code
xdg-open https://github.com/turtleshell8
