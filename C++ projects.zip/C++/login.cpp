#include <iostream>
#include <cmath>

int main(){
    int pass = 0;
    int exit = 0;
    std::cout << "enter a password: ";
    std::cin >> pass;
    int length = (pass == 0) ? 1 : static_cast<int>(log10(abs(pass)) + 1);
    if(pass == 1504 && length == 4){
        std::cout << "correct welcome" << "\n";
        std::cin >> exit;
        return 0;
    }
    else{
        std::cout << "incorrect by" << "\n";
        std::cin >> exit;
        return 0;
    }
}

