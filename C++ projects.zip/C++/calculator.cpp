#include <iostream>

int main(){
    // the sum variable is in the if statements
    int exit = 0;
    int op = 0;
    int add_1 = 0;
    int add_2 = 0;
    int sub_1 = 0;
    int sub_2 = 0;
    int mul_1 = 0;
    int mul_2 = 0;
    int div_1 = 0;
    int div_2 = 0;
    std::cout << "dev note: yes i am not working on my game rn" << std::endl;
    std::cout << "=================================================" << std::endl;
    std::cout << "1 = addition" << std::endl;
    std::cout << "2 = subtraction" << std::endl;
    std::cout << "3 = multiplication" << std::endl;
    std::cout << "4 = division" << std::endl;
    std::cout << "enter a operator: ";
    std::cin >> op;
    if(op == 1){
        std::cout << "enter the first number to add: ";
        std::cin >> add_1;
        std::cout << "enter the second number to add: ";
        std::cin >> add_2;
        int add_sum = add_1 + add_2;
        std::cout << "the answer is " << add_sum;
        std::cin >> exit;
    }
    if(op == 2){
        std::cout << "enter the first number to subtract: ";
        std::cin >> sub_1;
        std::cout << "enter the second number to subtract: ";
        std::cin >> sub_2;
        int sub_sum = sub_2 - sub_2;
        std::cout << "the answer is " << sub_sum;
        std::cin >> exit;

    }
    if(op == 3){
        std::cout << "enter the first number to multiply: ";
        std::cin >> mul_1;
        std::cout << "enter the second number to multiply: ";
        std::cin >> mul_2;
        int mul_sum = mul_1 * mul_2;
        std::cout << "the answer is " << mul_sum;
        std::cin >> exit;
    }
    if(op == 4){
        std::cout << "enter a number to divide: ";
        std::cin >> div_1;
        std::cout << "enter a number to dived: ";
        std::cin >> div_2;
        int div_sum = div_1 / div_2;
        std::cout << "this is your answer: " << div_sum;
    }
    return 0;
}